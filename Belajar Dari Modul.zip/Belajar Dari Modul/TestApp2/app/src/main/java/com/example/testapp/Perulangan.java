package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Perulangan extends AppCompatActivity {

    TextView output;
    EditText input;
    Button btnfor,btnwhile,btndowhile,btnclear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perulangan);
        input = findViewById(R.id.TextPengulangan);
        output = findViewById(R.id.Output);
        btnfor = findViewById(R.id.FOR);
        btnwhile = findViewById(R.id.WHILE);
        btndowhile = findViewById(R.id.DOWHILE);
        btnclear = findViewById(R.id.CLEAR);


        String date_n=new SimpleDateFormat("EEEE, MMM d yyyy", Locale.getDefault()).format(new Date());
        TextView date = findViewById(R.id.TextDate);
        date.setText(date_n);

        btnfor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer no = Integer.parseInt(input.getText().toString());
                StringBuilder tampil = new StringBuilder();
                for (int i = 0; i<=no;i++){
                    tampil.append(i);
                    output.setText(tampil);
                }
            }
        });
        btnwhile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer no = Integer.parseInt(input.getText().toString());
                StringBuilder tampil = new StringBuilder();
                int i = 0;
                while (i <=no){
                    tampil.append(i);
                    i++;
                }
                output.setText(tampil);
            }
        });
        btndowhile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer no = Integer.parseInt(input.getText().toString());
                StringBuilder tampil = new StringBuilder();
                int i = 0;
                do{
                    tampil.append(i);
                    i++;
                }while (i<=no);
                    output.setText(tampil);
            }
        });
        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                output.setText("");
            }
        });
    }
}