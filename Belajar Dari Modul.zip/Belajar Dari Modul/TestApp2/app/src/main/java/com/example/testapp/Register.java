package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Register extends AppCompatActivity {

    private CheckBox diklatoop,diklatandroid,diklatjs;
    private String menu1,menu2,menu3;
    private Button daftar;
    private TextView pilihan1,pilihan2,pilihan3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        diklatoop = findViewById(R.id.checkBox1);
        diklatandroid = findViewById(R.id.checkBox2);
        diklatjs = findViewById(R.id.checkBox3);
        pilihan1 = findViewById(R.id.pilihan1);
        pilihan2 = findViewById(R.id.pilihan2);
        pilihan3 = findViewById(R.id.pilihan3);
        daftar = findViewById(R.id.daftardikllat);

        String date_n = new SimpleDateFormat("EEEE, MMM d yyyy", Locale.getDefault()).format(new Date());
        TextView date = findViewById(R.id.TextDate);
        date.setText(date_n);

        daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(diklatoop.isChecked()){
                    menu1 = "Diklat OOP";
                }else{
                    menu1 = "";
                }

                if(diklatandroid.isChecked()){
                    menu2="Diklat Android";
                }else{
                    menu2="";
                }

                if(diklatjs.isChecked()){
                    menu3="Diklat JavaScript";
                }else{
                    menu3="";
                }

                if(!diklatoop.isChecked() && !diklatandroid.isChecked() && !diklatjs.isChecked()){
                    Toast.makeText(getApplicationContext(), "Tidak Ada Diklat Yang DIpilih", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Berhasil Mendaftar", Toast.LENGTH_SHORT).show();
                    pilihan1.setText("Pilihan1 : " + menu1);
                    pilihan2.setText("Pilihan 2 : "+ menu2);
                    pilihan3.setText("Pilihan 3 : "+menu3);
                }
            }
        });
    }
}