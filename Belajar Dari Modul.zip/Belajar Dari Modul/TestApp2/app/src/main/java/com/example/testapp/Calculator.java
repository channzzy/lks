package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Calculator extends AppCompatActivity {
    EditText angka1,angka2;
    TextView output;
    Double a1,a2,hasil;

    ImageView tambah,kurang,bagi,kali;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        angka1 = (EditText) findViewById(R.id.Angka1);
        angka2 = (EditText) findViewById(R.id.Angka2);
        output = (TextView) findViewById(R.id.Hasil);
        tambah = (ImageView) findViewById(R.id.Tambah);
        kurang = (ImageView) findViewById(R.id.Kurang);
        bagi = (ImageView) findViewById(R.id.Bagi);
        kali = (ImageView) findViewById(R.id.Kali);

        String date_n= new SimpleDateFormat("EEEE, MMM d yyyy", Locale.getDefault()).format(new Date());
        TextView date = findViewById(R.id.TextDate);
        date.setText(date_n);

        tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(angka1.getText().toString().equals("") || angka2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Harap Masukan Angka",Toast.LENGTH_SHORT).show();
                }else {
                    konvert();
                    hasil = a1+a2;
                    output.setText(Double.toString(hasil));
                }
            }
        });
        kurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(angka1.getText().toString().equals("") && angka2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Harap Masukan Angka",Toast.LENGTH_SHORT).show();
                }else{
                    konvert();
                    hasil = a1-a2;
                    output.setText(Double.toString(hasil));
                }
            }
        });
        bagi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(angka1.getText().toString().equals("") && angka2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Harap Masukan Angka", Toast.LENGTH_SHORT).show();
                }else {
                    konvert();
                    hasil = a1/a2;
                    output.setText(Double.toString(hasil));
                }
            }
        });
        kali.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(angka1.getText().toString().equals("") && angka2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Harap Masukan Angka", Toast.LENGTH_SHORT).show();
                }else {
                    konvert();
                    hasil = a1*a2;
                    output.setText(Double.toString(hasil));
                }
            }
        }));
    }
    public void konvert(){
        a1 = Double.parseDouble(angka1.getText().toString());
        a2 = Double.parseDouble(angka2.getText().toString());
    }
}