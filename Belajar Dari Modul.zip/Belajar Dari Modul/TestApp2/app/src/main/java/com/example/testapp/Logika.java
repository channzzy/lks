package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Logika extends AppCompatActivity {

    TextView input1,input2,output;
    Boolean v1,v2,hasil;
    Button and,or,not,xor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logika);

        input1 = (TextView) findViewById(R.id.Perbandingan1);
        input2 = (TextView) findViewById(R.id.Perbandingan2);
        output = (TextView) findViewById(R.id.HasilPerbandingan);
        and = (Button) findViewById(R.id.AND);
        or = (Button) findViewById(R.id.OR);
        not = (Button) findViewById(R.id.NOT);
        xor = (Button) findViewById(R.id.XOR);

        String date_n = new SimpleDateFormat("EEEE, MMM dd yyyy", Locale.getDefault()).format(new Date());
        TextView date = findViewById(R.id.TextDate);
        date.setText(date_n);

        //Logika AND
        and.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(input1.getText().toString().equals("") && input2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Harap Masukan Perbandingan", Toast.LENGTH_SHORT).show();
                }else {
                    konvert();
                    hasil=v1&&v2;
                    output.setText(Boolean.toString(hasil));
                }
            }
        });
        //Logika OR
        or.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(input1.getText().toString().equals("") && input2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Harap Masukan Perbandingan", Toast.LENGTH_SHORT).show();
                }else{
                    konvert();
                    hasil=v1||v2;
                    output.setText(Boolean.toString(hasil));
                }
            }
        });
        //Logika NOT
        not.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(input1.getText().toString().equals("") && input2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Harap Masukan Perbandingan", Toast.LENGTH_SHORT).show();
                }else{
                    konvert();
                    hasil=!v1;
                    output.setText(Boolean.toString(hasil));
                }
            }
        });
        //Logika XOR
        xor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(input1.getText().toString().equals("") && input2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Harap Masukan Perbandingan", Toast.LENGTH_SHORT).show();
                }else{
                    konvert();
                    hasil=v1^v2;
                    output.setText(Boolean.toString(hasil));
                }
            }
        });
    }
    public void konvert(){
        v1 = Boolean.parseBoolean(input1.getText().toString());
        v2 = Boolean.parseBoolean(input2.getText().toString());
    }
}