package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.InvalidMarkException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageView Calculator,logika,hitungnilai,daftar,perulangan;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String date_n = new SimpleDateFormat("EEEE, MMM d yyyy ",Locale.getDefault()).format(new Date());
        TextView date = findViewById(R.id.TextDate);
        date.setText(date_n);


        Calculator = (ImageView) findViewById(R.id.calculator);
        Calculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Calculator.class));
            }
        });
        logika = (ImageView) findViewById(R.id.logika);
        logika.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Logika.class));
            }
        });
        hitungnilai = findViewById(R.id.hitungnilai);
        hitungnilai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,CekNilai.class));
            }
        });
        daftar = findViewById(R.id.daftar);
        daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Register.class));
            }
        });
        perulangan = findViewById(R.id.perulangan);
        perulangan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Perulangan.class));
            }
        });
    }
}