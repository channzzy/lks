package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CekNilai extends AppCompatActivity {

    EditText input1,input2,input3;
    TextView hasil,ket;
    double uh,uts,uas,na;
    Button hitung;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cek_nilai);

        String date_n = new SimpleDateFormat("EEEE, MMM d yyyy", Locale.getDefault()).format(new Date());
        TextView date = findViewById(R.id.TextDate);
        date.setText(date_n);
        input1 = (EditText) findViewById(R.id.nilaiuh);
        input2 = (EditText) findViewById(R.id.nilaiuts);
        input3 = (EditText) findViewById(R.id.nilaiuas);
        hitung = (Button) findViewById(R.id.hitung);
        hasil = (TextView) findViewById(R.id.hasil);
        ket = (TextView) findViewById(R.id.TextKeterangan);



        hitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uh = Double.parseDouble(input1.getText().toString());
                uts = Double.parseDouble(input2.getText().toString());
                uas = Double.parseDouble(input3.getText().toString());
                na = (uh+uts+uas)/3;
                hasil.setText(Double.toString(na));
                if(na>70 && na<100){
                    ket.setText("Selamat Anda Lulus");
                } else if (na<70) {
                    ket.setText("Anda Tidak Lulus");
                }else if(input1.getText().toString().equals("") && input2.getText().toString().equals("") && input3.getText().toString().equals("")){
                    ket.setText("Masukan Semua Angka");
                }else{
                    ket.setText("Tidak Ada Angka");
                }
            }
        });
    }
}